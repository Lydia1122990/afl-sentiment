import os
import time
import json
import pandas as pd

from sentimentPerTeam.sentiment_bluesky import harvest_afl_sentiment, get_afl_teams
from esConnect.es_utils import save_to_elasticsearch

SEEN_FILE = "seen_uris.txt"

def load_seen_uris(file_path=SEEN_FILE):
    if not os.path.exists(file_path):
        return set()
    with open(file_path, "r") as f:
        return set(line.strip() for line in f.readlines())

def save_seen_uris(uris, file_path=SEEN_FILE):
    with open(file_path, "a") as f:
        for uri in uris:
            f.write(uri + "\n")

def main():
    print("🚀 Starting AFL Bluesky sentiment harvest")

    seen_uris = load_seen_uris()
    all_posts = []
    new_uris = set()

    teams = get_afl_teams()
    for team in teams:
        print(f"🔍 Harvesting posts for {team}...")
        posts = harvest_afl_sentiment(team, limit=100)
        time.sleep(5)

        team_posts = []
        for post in posts:
            if post["url"] in seen_uris:
                continue

            new_uris.add(post["url"])
            post_cleaned = {k: v for k, v in post.items() if k not in ['_index', '_id']}
            doc_id = f"{team}_{len(team_posts)}"

            all_posts.append(post_cleaned)
            team_posts.append((doc_id, post_cleaned))

            save_to_elasticsearch([post_cleaned], index_name="afl_bluesky_sentiment", doc_id=doc_id)

    # 保存已处理过的 URI
    save_seen_uris(new_uris)

    # Bulk 保存全部到 Elasticsearch
    save_to_elasticsearch(all_posts, index_name="afl_bluesky_sentiment")

    # 本地备份保存
    os.makedirs("results", exist_ok=True)
    df = pd.DataFrame(all_posts)
    df.to_csv("results/afl_posts.csv", index=False)
    with open("results/afl_posts.json", "w", encoding="utf-8") as f:
        json.dump(all_posts, f, ensure_ascii=False, indent=2)

    print("✅ Harvest complete. Results saved to CSV, JSON, and Elasticsearch.")

# 可选：用于本地调试运行
if __name__ == "__main__":
    main()
