
def main():
    try:
        from mastodon import Mastodon
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        
        es_user_path = "/secrets/default/elastic-secret-mastodon/ES_USERNAME"
        es_password_path = "/secrets/default/elastic-secret-mastodon/ES_PASSWORD"
        mastodon_token_path = "/secrets/default/elastic-secret-mastodon/MASTODON_ACCESS_TOKEN"
        # Read secrets
        with open(es_user_path, 'r') as f:
            es_username = f.read().strip()
        with open(es_password_path, 'r') as f:
            es_password = f.read().strip()
        with open(mastodon_token_path, 'r') as f:
            mastodon_token = f.read().strip()

        # Initialize clients
        mastodon = Mastodon(
            access_token=mastodon_token,
            api_base_url="https://mastodon.social"
        )
        sentiment_analyser = SentimentIntensityAnalyzer()

        # Optionally return to confirm init
        return {"statusCode": 200, "body": f"✅ Init complete, ES user: {es_username}"}

    except Exception as e:
        return {"statusCode": 500, "body": f"🔥 Init failed: {e}"}

